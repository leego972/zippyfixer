const { chromium } = require('playwright');

class BrowserController {
  constructor(emit, logger) {
    this.browser = null;
    this.page = null;
    this.emit = emit;
    this.logger = logger;
  }

  async launch() {
    this.browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    });
    const context = await this.browser.newContext({
      viewport: { width: 1280, height: 800 },
      userAgent:
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36',
    });
    this.page = await context.newPage();

    this.page.on('console', (msg) => {
      if (msg.type() === 'error') {
        this.logger.logBug({
          title: `Console Error: ${msg.text().slice(0, 80)}`,
          description: msg.text(),
          severity: 'high',
          url: this.page.url(),
          category: 'console-error',
        });
        this.emit('console-error', { text: msg.text(), url: this.page.url() });
      }
    });

    this.page.on('pageerror', (err) => {
      this.logger.logBug({
        title: `Page JS Error: ${err.message.slice(0, 80)}`,
        description: err.message,
        severity: 'critical',
        url: this.page.url(),
        category: 'js-error',
      });
      this.emit('page-error', { message: err.message, url: this.page.url() });
    });

    this.page.on('response', (response) => {
      if (response.status() >= 400) {
        this.emit('http-error', {
          url: response.url(),
          status: response.status(),
          pageUrl: this.page.url(),
        });
        if (response.status() >= 500) {
          this.logger.logBug({
            title: `HTTP ${response.status()} on ${response.url().split('?')[0].slice(-60)}`,
            description: `Server returned ${response.status()} for ${response.url()}`,
            severity: 'critical',
            url: this.page.url(),
            category: 'http-error',
          });
        } else if (response.status() >= 400) {
          this.logger.logBug({
            title: `HTTP ${response.status()} on ${response.url().split('?')[0].slice(-60)}`,
            description: `Client error ${response.status()} for ${response.url()}`,
            severity: 'medium',
            url: this.page.url(),
            category: 'http-error',
          });
        }
      }
    });
  }

  async navigate(url) {
    try {
      await this.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 15000 });
      await this.page.waitForTimeout(1000);
      const title = await this.page.title();
      this.logger.logPageVisit(this.page.url(), title);
      this.emit('navigated', { url: this.page.url(), title });
      return { url: this.page.url(), title, success: true };
    } catch (err) {
      this.logger.logBug({
        title: `Navigation failed: ${url}`,
        description: err.message,
        severity: 'critical',
        url,
        category: 'navigation',
      });
      return { url, success: false, error: err.message };
    }
  }

  async getPageContent() {
    const url = this.page.url();
    const title = await this.page.title();
    const content = await this.page.evaluate(() => {
      const body = document.body;
      return {
        text: body ? body.innerText.slice(0, 6000) : '',
        links: Array.from(document.querySelectorAll('a[href]'))
          .slice(0, 30)
          .map((a) => ({ text: a.innerText.trim().slice(0, 60), href: a.href })),
        buttons: Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]'))
          .slice(0, 20)
          .map((b) => ({
            text: (b.innerText || b.value || b.getAttribute('aria-label') || '').trim().slice(0, 60),
            type: b.tagName.toLowerCase(),
            disabled: b.disabled,
          })),
        inputs: Array.from(document.querySelectorAll('input:not([type="hidden"]), textarea, select'))
          .slice(0, 15)
          .map((i) => ({
            type: i.type || i.tagName.toLowerCase(),
            name: i.name,
            placeholder: i.placeholder,
            label: document.querySelector(`label[for="${i.id}"]`)?.innerText || '',
          })),
        forms: Array.from(document.querySelectorAll('form')).length,
        images: Array.from(document.querySelectorAll('img'))
          .filter((img) => !img.complete || img.naturalWidth === 0)
          .slice(0, 5)
          .map((img) => ({ src: img.src, alt: img.alt })),
      };
    });
    return { url, title, ...content };
  }

  async click(selector, description) {
    try {
      const locator = this.page.locator(selector).first();
      await locator.waitFor({ state: 'visible', timeout: 5000 });
      await locator.click({ timeout: 5000 });
      await this.page.waitForTimeout(800);
      this.logger.logAction({ type: 'click', selector, description });
      this.emit('action', { type: 'click', selector, description, url: this.page.url() });
      return { success: true, newUrl: this.page.url() };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async clickByText(text, tagHint) {
    try {
      const tag = tagHint || 'button, a, [role="button"]';
      const locator = this.page.getByRole('button', { name: text, exact: false });
      const count = await locator.count();
      if (count > 0) {
        await locator.first().click({ timeout: 5000 });
      } else {
        await this.page.getByText(text, { exact: false }).first().click({ timeout: 5000 });
      }
      await this.page.waitForTimeout(800);
      this.logger.logAction({ type: 'click-text', text, description: `Clicked "${text}"` });
      this.emit('action', { type: 'click-text', text, url: this.page.url() });
      return { success: true, newUrl: this.page.url() };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async fillInput(selector, value) {
    try {
      const locator = this.page.locator(selector).first();
      await locator.waitFor({ state: 'visible', timeout: 5000 });
      await locator.fill(value, { timeout: 5000 });
      await this.page.waitForTimeout(400);
      this.logger.logAction({ type: 'fill', selector, value, description: `Filled input with "${value}"` });
      this.emit('action', { type: 'fill', selector, value, url: this.page.url() });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async screenshot(name) {
    try {
      const buffer = await this.page.screenshot({ type: 'jpeg', quality: 70, fullPage: false });
      const base64 = buffer.toString('base64');
      this.logger.logScreenshot(name || `screenshot-${Date.now()}`, base64, this.page.url());
      this.emit('screenshot', { name, url: this.page.url(), preview: `data:image/jpeg;base64,${base64.slice(0, 200)}...` });
      return { success: true, base64 };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async scroll(direction) {
    try {
      if (direction === 'down') {
        await this.page.evaluate(() => window.scrollBy(0, 600));
      } else if (direction === 'up') {
        await this.page.evaluate(() => window.scrollBy(0, -600));
      } else if (direction === 'bottom') {
        await this.page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      } else if (direction === 'top') {
        await this.page.evaluate(() => window.scrollTo(0, 0));
      }
      await this.page.waitForTimeout(400);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  async checkBrokenImages() {
    const broken = await this.page.evaluate(() => {
      return Array.from(document.querySelectorAll('img'))
        .filter((img) => !img.complete || img.naturalWidth === 0)
        .map((img) => ({ src: img.src, alt: img.alt }));
    });
    return broken;
  }

  async checkAccessibility() {
    return await this.page.evaluate(() => {
      const issues = [];
      document.querySelectorAll('img:not([alt])').forEach((img) => {
        issues.push({ type: 'missing-alt', element: 'img', src: img.src.slice(-60) });
      });
      document.querySelectorAll('a:not([href]), a[href=""], a[href="#"]').forEach((a) => {
        issues.push({ type: 'empty-link', text: a.innerText.trim().slice(0, 40) });
      });
      document.querySelectorAll('button:not([type])').forEach((b) => {
        issues.push({ type: 'button-no-type', text: b.innerText.trim().slice(0, 40) });
      });
      document.querySelectorAll('input:not([label]):not([aria-label]):not([placeholder])').forEach((i) => {
        issues.push({ type: 'unlabeled-input', inputType: i.type, name: i.name });
      });
      return issues.slice(0, 20);
    });
  }

  async goBack() {
    try {
      await this.page.goBack({ timeout: 8000 });
      await this.page.waitForTimeout(600);
      return { success: true, url: this.page.url() };
    } catch {
      return { success: false };
    }
  }

  async currentUrl() {
    return this.page.url();
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }
}

module.exports = { BrowserController };
