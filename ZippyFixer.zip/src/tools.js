const { GitHubClient } = require('./github');
const { RailwayClient } = require('./railway');

const TOOLS = [
  // ── Browser tools ──
  {
    name: 'navigate',
    description: 'Navigate the browser to a URL',
    parameters: { type: 'object', properties: { url: { type: 'string', description: 'Full URL to navigate to' } }, required: ['url'] },
  },
  {
    name: 'get_page_content',
    description: 'Get current page content: visible text, links, buttons, inputs, and forms',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'click',
    description: 'Click an element by CSS selector',
    parameters: {
      type: 'object',
      properties: {
        selector: { type: 'string', description: 'CSS selector for the element' },
        description: { type: 'string', description: 'What you are clicking' },
      },
      required: ['selector'],
    },
  },
  {
    name: 'click_by_text',
    description: 'Click an element by its visible text (button, link, etc.)',
    parameters: { type: 'object', properties: { text: { type: 'string', description: 'Visible text of the element' } }, required: ['text'] },
  },
  {
    name: 'fill_input',
    description: 'Fill a text input, textarea, or select field',
    parameters: {
      type: 'object',
      properties: {
        selector: { type: 'string', description: 'CSS selector for the input' },
        value: { type: 'string', description: 'Value to type in' },
      },
      required: ['selector', 'value'],
    },
  },
  {
    name: 'screenshot',
    description: 'Take a screenshot of the current page state',
    parameters: { type: 'object', properties: { name: { type: 'string', description: 'Descriptive name for this screenshot' } } },
  },
  {
    name: 'scroll',
    description: 'Scroll the page',
    parameters: { type: 'object', properties: { direction: { type: 'string', enum: ['down', 'up', 'top', 'bottom'] } }, required: ['direction'] },
  },
  {
    name: 'go_back',
    description: 'Navigate back to the previous page',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'check_broken_images',
    description: 'Check for broken or missing images on the current page',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'check_accessibility',
    description: 'Check for basic accessibility issues: missing alt text, unlabeled inputs, empty links',
    parameters: { type: 'object', properties: {} },
  },

  // ── GitHub tools ──
  {
    name: 'github_list_repos',
    description: 'List the authenticated user\'s GitHub repositories',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'github_list_files',
    description: 'List files and folders in a GitHub repository path',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'Path inside the repo (leave blank for root)' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_read_file',
    description: 'Read the contents of a file from a GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path inside the repo' },
      },
      required: ['owner', 'repo', 'path'],
    },
  },
  {
    name: 'github_write_file',
    description: 'Create or update a file in a GitHub repository to fix a bug or apply a change',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path inside the repo' },
        content: { type: 'string', description: 'Full new file content' },
        message: { type: 'string', description: 'Commit message describing the fix' },
        sha: { type: 'string', description: 'Current file SHA (required when updating existing file)' },
      },
      required: ['owner', 'repo', 'path', 'content', 'message'],
    },
  },
  {
    name: 'github_create_branch',
    description: 'Create a new branch in a GitHub repository (use before making fixes)',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        branch: { type: 'string', description: 'New branch name (e.g. fix/broken-button)' },
        from: { type: 'string', description: 'Base branch name (defaults to main)' },
      },
      required: ['owner', 'repo', 'branch'],
    },
  },
  {
    name: 'github_create_pr',
    description: 'Open a Pull Request with your fixes',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        title: { type: 'string', description: 'PR title' },
        body: { type: 'string', description: 'PR description with list of bugs fixed' },
        head: { type: 'string', description: 'Branch containing your changes' },
        base: { type: 'string', description: 'Target branch (defaults to main)' },
      },
      required: ['owner', 'repo', 'title', 'body', 'head'],
    },
  },
  {
    name: 'github_create_issue',
    description: 'Log a bug as a GitHub Issue in the repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
        title: { type: 'string', description: 'Issue title' },
        body: { type: 'string', description: 'Issue body with bug description and steps to reproduce' },
        labels: { type: 'array', items: { type: 'string' }, description: 'Labels to apply (e.g. ["bug"])' },
      },
      required: ['owner', 'repo', 'title', 'body'],
    },
  },
  {
    name: 'github_get_commits',
    description: 'Get recent commits for a GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'GitHub username or org' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },

  // ── Railway tools ──
  {
    name: 'railway_list_projects',
    description: 'List all Railway projects for the authenticated user',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'railway_get_deployments',
    description: 'Get recent deployments for a Railway project',
    parameters: {
      type: 'object',
      properties: {
        projectId: { type: 'string', description: 'Railway project ID' },
      },
      required: ['projectId'],
    },
  },
  {
    name: 'railway_get_logs',
    description: 'Get deployment logs from Railway to check for runtime errors',
    parameters: {
      type: 'object',
      properties: {
        deploymentId: { type: 'string', description: 'Railway deployment ID' },
      },
      required: ['deploymentId'],
    },
  },
  {
    name: 'railway_redeploy',
    description: 'Trigger a redeploy on Railway (use after pushing a fix)',
    parameters: {
      type: 'object',
      properties: {
        serviceId: { type: 'string', description: 'Railway service ID' },
        environmentId: { type: 'string', description: 'Railway environment ID' },
      },
      required: ['serviceId', 'environmentId'],
    },
  },

  // ── Logging tools ──
  {
    name: 'log_bug',
    description: 'Log a bug or issue found during testing',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Short bug title (max 80 characters)' },
        description: { type: 'string', description: 'Full description: what happened, what was expected, steps to reproduce' },
        severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low', 'info'], description: 'critical=crash, high=major broken feature, medium=partial, low=cosmetic, info=suggestion' },
        category: { type: 'string', enum: ['ui', 'functionality', 'navigation', 'performance', 'accessibility', 'content', 'http-error', 'js-error', 'console-error', 'missing-feature', 'general'], description: 'Bug category' },
        selector: { type: 'string', description: 'CSS selector or element reference (optional)' },
      },
      required: ['title', 'description', 'severity', 'category'],
    },
  },
  {
    name: 'set_summary',
    description: 'Set the final test summary — call this LAST after all testing and fixes are complete',
    parameters: {
      type: 'object',
      properties: {
        summary: { type: 'string', description: 'Full test summary: quality rating, key findings, fixes applied, remaining recommendations' },
      },
      required: ['summary'],
    },
  },
];

function buildSystemPrompt(url, instructions, testDepth, hasGitHub, hasRailway) {
  const depth = testDepth || 'standard';
  const actionTargets = { quick: '10–15', standard: '25–40', deep: '50–70' };

  return `You are ZippyFixer — an expert QA engineer, beta tester, and developer. You test websites like a real user AND fix bugs directly in the source code when given access.

TARGET: ${url}
DEPTH: ${depth.toUpperCase()} (aim for ${actionTargets[depth] || '25–40'} meaningful actions)
${hasGitHub ? '✅ GitHub access: you CAN read repos, make code changes, create branches and PRs' : ''}
${hasRailway ? '✅ Railway access: you CAN check deployments, read logs, trigger redeploys' : ''}

TESTING CHECKLIST:
1. Navigation — all links, menus, internal routes working? Dead links? 404s?
2. Forms — validation, submission, error messages, success feedback
3. Buttons — every button responds and does what it implies?
4. Images — check_broken_images on each page
5. Content — placeholder text ("Lorem ipsum"), missing text, incomplete sections?
6. Console & HTTP errors — auto-logged, but also run check_accessibility
7. Accessibility — missing alt text, unlabeled inputs, empty links
8. Missing features — things that look like features but don't work
${hasGitHub ? `
GITHUB WORKFLOW (when repo is provided):
- Use github_list_repos to find the right repo
- Use github_read_file to inspect code causing bugs
- Create a fix branch: github_create_branch (e.g. fix/login-validation)
- Apply fixes: github_write_file with clear commit messages
- Open a PR: github_create_pr summarizing all bugs fixed
- Log unfixed bugs as issues: github_create_issue with label "bug"
` : ''}
${hasRailway ? `
RAILWAY WORKFLOW:
- Use railway_list_projects to find the project
- Check railway_get_deployments to see deployment status
- If a deployment failed, read railway_get_logs for error details
- After pushing a fix via GitHub, trigger railway_redeploy
` : ''}
SEVERITY GUIDE:
- critical: crash/won't load/data loss
- high: core feature broken
- medium: partially broken
- low: cosmetic
- info: suggestion

${instructions ? `USER INSTRUCTIONS:\n${instructions}` : ''}

Start testing now. Be thorough. When done, call set_summary with a full report of what you found and what you fixed.`;
}

async function executeTool(name, args, browser, logger, emit, tokens = {}) {
  emit('tool-call', { name, args: JSON.stringify(args).slice(0, 150) });

  // GitHub tools
  if (name.startsWith('github_')) {
    if (!tokens.github) return { error: 'No GitHub token provided. Add it in the GitHub Token field.' };
    const gh = new GitHubClient(tokens.github);
    try {
      switch (name) {
        case 'github_list_repos': return await gh.listRepos();
        case 'github_list_files': return await gh.listContents(args.owner, args.repo, args.path || '');
        case 'github_read_file': return await gh.getFile(args.owner, args.repo, args.path);
        case 'github_write_file': return await gh.createOrUpdateFile(args.owner, args.repo, args.path, args.content, args.message, args.sha);
        case 'github_create_branch': return await gh.createBranch(args.owner, args.repo, args.branch, args.from);
        case 'github_create_pr': {
          const pr = await gh.createPullRequest(args.owner, args.repo, { title: args.title, body: args.body, head: args.head, base: args.base });
          emit('github-pr', { url: pr.html_url, title: args.title });
          return pr;
        }
        case 'github_create_issue': {
          const issue = await gh.createIssue(args.owner, args.repo, { title: args.title, body: args.body, labels: args.labels || ['bug'] });
          emit('github-issue', { url: issue.html_url, title: args.title });
          return issue;
        }
        case 'github_get_commits': return await gh.getCommits(args.owner, args.repo);
        default: return { error: `Unknown GitHub tool: ${name}` };
      }
    } catch (err) { return { error: err.message }; }
  }

  // Railway tools
  if (name.startsWith('railway_')) {
    if (!tokens.railway) return { error: 'No Railway token provided. Add it in the Railway Token field.' };
    const rw = new RailwayClient(tokens.railway);
    try {
      switch (name) {
        case 'railway_list_projects': return await rw.listProjects();
        case 'railway_get_deployments': return await rw.getDeployments(args.projectId);
        case 'railway_get_logs': return await rw.getLogs(args.deploymentId);
        case 'railway_redeploy': return await rw.triggerRedeploy(args.serviceId, args.environmentId);
        default: return { error: `Unknown Railway tool: ${name}` };
      }
    } catch (err) { return { error: err.message }; }
  }

  // Browser & logging tools
  try {
    switch (name) {
      case 'navigate':              return await browser.navigate(args.url);
      case 'get_page_content':      return await browser.getPageContent();
      case 'click':                 return await browser.click(args.selector, args.description);
      case 'click_by_text':         return await browser.clickByText(args.text);
      case 'fill_input':            return await browser.fillInput(args.selector, args.value);
      case 'screenshot':            return await browser.screenshot(args.name);
      case 'scroll':                return await browser.scroll(args.direction);
      case 'go_back':               return await browser.goBack();
      case 'check_broken_images':   return await browser.checkBrokenImages();
      case 'check_accessibility':   return await browser.checkAccessibility();
      case 'log_bug': {
        const bug = logger.logBug({ ...args, url: await browser.currentUrl() });
        emit('bug-logged', bug);
        return { success: true, bugId: bug.id };
      }
      case 'set_summary':
        logger.setSummary(args.summary);
        emit('summary-set', { summary: args.summary });
        return { success: true };
      default:
        return { error: `Unknown tool: ${name}` };
    }
  } catch (err) {
    return { error: err.message };
  }
}

module.exports = { TOOLS, buildSystemPrompt, executeTool };
