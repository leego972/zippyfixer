class BugLogger {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.startTime = new Date();
    this.bugs = [];
    this.actions = [];
    this.screenshots = [];
    this.pagesVisited = [];
    this.testSummary = '';
  }

  logBug({ title, description, severity, url, selector, category }) {
    const bug = {
      id: `BUG-${String(this.bugs.length + 1).padStart(3, '0')}`,
      title: title || 'Untitled Bug',
      description: description || '',
      severity: severity || 'medium',
      url: url || '',
      selector: selector || '',
      category: category || 'general',
      timestamp: new Date().toISOString(),
    };
    this.bugs.push(bug);
    return bug;
  }

  logAction(action) {
    this.actions.push({
      ...action,
      timestamp: new Date().toISOString(),
    });
  }

  logScreenshot(name, base64Data, url) {
    this.screenshots.push({ name, base64Data, url, timestamp: new Date().toISOString() });
  }

  logPageVisit(url, title) {
    if (!this.pagesVisited.find((p) => p.url === url)) {
      this.pagesVisited.push({ url, title, timestamp: new Date().toISOString() });
    }
  }

  setSummary(summary) {
    this.testSummary = summary;
  }

  getReport() {
    const endTime = new Date();
    const durationMs = endTime - this.startTime;
    const duration = `${Math.floor(durationMs / 60000)}m ${Math.floor((durationMs % 60000) / 1000)}s`;

    const bySeverity = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
    this.bugs.forEach((b) => {
      if (bySeverity[b.severity] !== undefined) bySeverity[b.severity]++;
    });

    return {
      sessionId: this.sessionId,
      startTime: this.startTime.toISOString(),
      endTime: endTime.toISOString(),
      duration,
      totalBugs: this.bugs.length,
      bySeverity,
      bugs: this.bugs,
      actions: this.actions,
      screenshots: this.screenshots,
      pagesVisited: this.pagesVisited,
      summary: this.testSummary,
    };
  }
}

module.exports = { BugLogger };
