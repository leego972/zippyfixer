const socket = io();
let sessionId = null;
let report = null;
let actionCount = 0;
const bugCounts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
let pageCount = 0;

const MODEL_HINTS = {
  openai: 'Default: gpt-4o — also supports gpt-4-turbo, gpt-4o-mini',
  anthropic: 'Default: claude-3-5-sonnet-20241022 — also supports claude-3-opus-20240229',
  groq: 'Default: llama-3.3-70b-versatile — also supports mixtral-8x7b-32768, gemma2-9b-it',
  openrouter: 'Default: openai/gpt-4o — supports any OpenRouter model slug',
};

// ── DOM refs ──
const urlInput = document.getElementById('url');
const providerSel = document.getElementById('provider');
const modelInput = document.getElementById('model');
const apiKeyInput = document.getElementById('apiKey');
const toggleKeyBtn = document.getElementById('toggleKey');
const testDepthSel = document.getElementById('testDepth');
const instructionsTA = document.getElementById('instructions');
const startBtn = document.getElementById('startBtn');
const modelHints = document.getElementById('modelHints');

const configPanel = document.getElementById('configPanel');
const sessionPanel = document.getElementById('sessionPanel');
const sessionTitle = document.getElementById('sessionTitle');
const sessionMeta = document.getElementById('sessionMeta');
const stopBtn = document.getElementById('stopBtn');
const newTestBtn = document.getElementById('newTestBtn');
const newTestBtn2 = document.getElementById('newTestBtn2');
const pulseDot = document.getElementById('pulseDot');
const logStatus = document.getElementById('logStatus');
const logScroll = document.getElementById('logScroll');
const bugsList = document.getElementById('bugsList');
const bugCount = document.getElementById('bugCount');
const exportBtn = document.getElementById('exportBtn');
const exportHtmlBtn = document.getElementById('exportHtmlBtn');
const exportJsonBtn2 = document.getElementById('exportJsonBtn2');
const summaryPanel = document.getElementById('summaryPanel');
const summaryText = document.getElementById('summaryText');

const statActions = document.getElementById('statActions');
const statCritical = document.getElementById('statCritical');
const statHigh = document.getElementById('statHigh');
const statMedium = document.getElementById('statMedium');
const statLow = document.getElementById('statLow');
const statPages = document.getElementById('statPages');

// ── Model hints ──
providerSel.addEventListener('change', () => {
  modelHints.textContent = MODEL_HINTS[providerSel.value] || '';
  modelInput.placeholder = getModelPlaceholder(providerSel.value);
});
modelHints.textContent = MODEL_HINTS[providerSel.value];

function getModelPlaceholder(p) {
  const map = {
    openai: 'gpt-4o',
    anthropic: 'claude-3-5-sonnet-20241022',
    groq: 'llama-3.3-70b-versatile',
    openrouter: 'openai/gpt-4o',
  };
  return map[p] || '';
}
modelInput.placeholder = getModelPlaceholder(providerSel.value);

// ── Toggle API key visibility ──
toggleKeyBtn.addEventListener('click', () => {
  apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
});

// ── Start test ──
startBtn.addEventListener('click', async () => {
  const url = urlInput.value.trim();
  const provider = providerSel.value;
  const apiKey = apiKeyInput.value.trim();
  const model = modelInput.value.trim();
  const testDepth = testDepthSel.value;
  const instructions = instructionsTA.value.trim();

  if (!url) return alert('Please enter a target URL.');
  if (!apiKey) return alert('Please enter your API key.');
  if (!url.startsWith('http')) return alert('URL must start with http:// or https://');

  startBtn.disabled = true;
  startBtn.textContent = 'Starting...';

  try {
    const res = await fetch('/api/start-test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, provider, apiKey, model, testDepth, instructions }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to start');

    sessionId = data.sessionId;
    socket.emit('join-session', sessionId);
    showSession(url, provider, model, testDepth);
  } catch (err) {
    alert('Error: ' + err.message);
    startBtn.disabled = false;
    startBtn.innerHTML = `<svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><polygon points="5,3 19,12 5,21"/></svg> Start BetaTest`;
  }
});

function showSession(url, provider, model, depth) {
  configPanel.classList.add('hidden');
  sessionPanel.classList.remove('hidden');
  sessionTitle.textContent = `Testing ${url}`;
  sessionMeta.textContent = `Provider: ${provider.toUpperCase()} ${model ? '· ' + model : ''} · Depth: ${depth}`;
  resetStats();
  clearLog();
  clearBugs();
  summaryPanel.classList.add('hidden');
  stopBtn.classList.remove('hidden');
  newTestBtn.classList.add('hidden');
  newTestBtn2.classList.add('hidden');
  exportBtn.classList.add('hidden');
  exportHtmlBtn.classList.add('hidden');
  exportJsonBtn2.classList.add('hidden');
}

function resetStats() {
  actionCount = 0;
  Object.keys(bugCounts).forEach((k) => (bugCounts[k] = 0));
  pageCount = 0;
  statActions.textContent = '0';
  statCritical.textContent = '0';
  statHigh.textContent = '0';
  statMedium.textContent = '0';
  statLow.textContent = '0';
  statPages.textContent = '0';
  bugCount.textContent = '0';
  pulseDot.className = 'pulse-dot';
}

function clearLog() { logScroll.innerHTML = ''; }
function clearBugs() { bugsList.innerHTML = '<div class="empty-bugs">No bugs found yet...</div>'; }

// ── Log helpers ──
function addLog(msg, type = 'status', icon = '·') {
  const now = new Date().toLocaleTimeString('en', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const entry = document.createElement('div');
  entry.className = `log-entry type-${type}`;
  entry.innerHTML = `<span class="log-time">${now}</span><span class="log-icon">${icon}</span><span class="log-msg">${escHtml(msg)}</span>`;
  logScroll.appendChild(entry);
  logScroll.scrollTop = logScroll.scrollHeight;
}

function escHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ── Socket events ──
socket.on('test-started', ({ url, provider }) => {
  addLog(`Test session started → ${url}`, 'status', '🚀');
  logStatus.textContent = 'Running...';
});

socket.on('status', ({ message }) => {
  addLog(message, 'status', '⚙');
  logStatus.textContent = message.slice(0, 60);
});

socket.on('navigated', ({ url, title }) => {
  pageCount++;
  statPages.textContent = pageCount;
  addLog(`Navigated to: ${title || url} — ${url}`, 'nav', '🌐');
  actionCount++;
  statActions.textContent = actionCount;
});

socket.on('action', ({ type, selector, description, text, url }) => {
  const label = description || text || selector || type;
  addLog(`${type === 'fill' ? 'Filled input' : 'Clicked'}: ${label}`, 'action', '👆');
  actionCount++;
  statActions.textContent = actionCount;
});

socket.on('tool-call', ({ name, args }) => {
  const friendlyNames = {
    navigate: 'Navigate',
    get_page_content: 'Read page',
    click: 'Click element',
    click_by_text: 'Click by text',
    fill_input: 'Fill input',
    screenshot: 'Screenshot',
    scroll: 'Scroll',
    go_back: 'Go back',
    check_broken_images: 'Check images',
    check_accessibility: 'Check accessibility',
    log_bug: 'Log bug',
    set_summary: 'Write summary',
  };
  const fname = friendlyNames[name] || name;
  addLog(`AI tool → ${fname}: ${args.slice(0, 80)}`, 'action', '🔧');
});

socket.on('ai-thinking', ({ iteration }) => {
  logStatus.textContent = `AI working... (step ${iteration})`;
});

socket.on('bug-logged', (bug) => {
  addLog(`BUG [${bug.severity.toUpperCase()}] ${bug.title}`, bug.severity === 'critical' ? 'critical' : 'bug', '🐛');
  if (bugCounts[bug.severity] !== undefined) {
    bugCounts[bug.severity]++;
    document.getElementById(`stat${capitalize(bug.severity)}`).textContent = bugCounts[bug.severity];
  }
  appendBugCard(bug);
  const total = Object.values(bugCounts).reduce((a, b) => a + b, 0);
  bugCount.textContent = total;
  exportBtn.classList.remove('hidden');
});

socket.on('console-error', ({ text, url }) => {
  addLog(`Console error at ${url}: ${text.slice(0, 100)}`, 'error', '⚠');
});

socket.on('page-error', ({ message }) => {
  addLog(`JS Error: ${message.slice(0, 100)}`, 'critical', '💥');
});

socket.on('http-error', ({ url, status }) => {
  addLog(`HTTP ${status} — ${url.slice(0, 80)}`, 'error', '🔴');
});

socket.on('screenshot', ({ name, url }) => {
  addLog(`Screenshot taken: "${name}" on ${url}`, 'status', '📸');
});

socket.on('summary-set', ({ summary }) => {
  summaryText.textContent = summary;
  summaryPanel.classList.remove('hidden');
  addLog('Test summary written.', 'status', '📋');
});

socket.on('test-complete', ({ report: r }) => {
  report = r;
  pulseDot.className = 'pulse-dot done';
  logStatus.textContent = `Done — ${r.totalBugs} bug${r.totalBugs !== 1 ? 's' : ''} found in ${r.duration}`;
  addLog(`✅ Test complete in ${r.duration}. ${r.totalBugs} total bugs.`, 'status', '✅');
  stopBtn.classList.add('hidden');
  newTestBtn.classList.remove('hidden');
  newTestBtn2.classList.remove('hidden');
  exportHtmlBtn.classList.remove('hidden');
  exportJsonBtn2.classList.remove('hidden');
});

socket.on('test-error', ({ message }) => {
  pulseDot.className = 'pulse-dot error';
  logStatus.textContent = 'Error: ' + message.slice(0, 60);
  addLog('Error: ' + message, 'error', '❌');
  stopBtn.classList.add('hidden');
  newTestBtn.classList.remove('hidden');
});

// ── Bug card ──
function appendBugCard(bug) {
  const empty = bugsList.querySelector('.empty-bugs');
  if (empty) empty.remove();

  const card = document.createElement('div');
  card.className = `bug-card sev-${bug.severity}`;
  card.innerHTML = `
    <div class="bug-top">
      <span class="bug-id">${bug.id}</span>
      <span class="sev-badge ${bug.severity}">${bug.severity}</span>
      <span class="cat-badge">${bug.category}</span>
    </div>
    <div class="bug-title">${escHtml(bug.title)}</div>
    <div class="bug-desc">${escHtml(bug.description)}</div>
    ${bug.url ? `<div class="bug-url">${escHtml(bug.url)}</div>` : ''}
  `;
  bugsList.appendChild(card);
  bugsList.scrollTop = bugsList.scrollHeight;
}

// ── Stop / new test ──
stopBtn.addEventListener('click', async () => {
  if (!sessionId) return;
  await fetch(`/api/stop-test/${sessionId}`, { method: 'POST' });
  addLog('Test stopped by user.', 'status', '⏹');
  stopBtn.classList.add('hidden');
  newTestBtn.classList.remove('hidden');
  pulseDot.className = 'pulse-dot error';
  logStatus.textContent = 'Stopped';
});

[newTestBtn, newTestBtn2].forEach((btn) =>
  btn.addEventListener('click', () => {
    sessionPanel.classList.add('hidden');
    configPanel.classList.remove('hidden');
    sessionId = null;
    report = null;
    startBtn.disabled = false;
    startBtn.innerHTML = `<svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><polygon points="5,3 19,12 5,21"/></svg> Start BetaTest`;
  })
);

// ── Export ──
exportBtn.addEventListener('click', exportJson);
exportJsonBtn2.addEventListener('click', exportJson);

function exportJson() {
  if (!report && !sessionId) return;
  const download = (data) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `betatesterai-report-${sessionId || Date.now()}.json`;
    a.click();
  };
  if (report) { download(report); return; }
  fetch(`/api/report/${sessionId}`).then((r) => r.json()).then(download);
}

exportHtmlBtn.addEventListener('click', () => {
  if (!report) return;
  const html = generateHtmlReport(report);
  const blob = new Blob([html], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `betatesterai-report-${sessionId}.html`;
  a.click();
});

function generateHtmlReport(r) {
  const sevColor = { critical: '#ef4444', high: '#f97316', medium: '#eab308', low: '#22c55e', info: '#3b82f6' };
  const bugsHtml = r.bugs.map((b) => `
    <div style="border:1px solid #2e3248;border-left:4px solid ${sevColor[b.severity]||'#6366f1'};border-radius:8px;padding:14px 16px;margin-bottom:10px;background:#1a1d27;">
      <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
        <span style="font-size:11px;color:#8b90a8;font-family:monospace;">${b.id}</span>
        <span style="background:${sevColor[b.severity]}22;color:${sevColor[b.severity]};font-size:11px;padding:2px 8px;border-radius:4px;font-weight:700;text-transform:uppercase;">${b.severity}</span>
        <span style="background:#22263a;color:#8b90a8;font-size:11px;padding:2px 8px;border-radius:4px;">${b.category}</span>
      </div>
      <div style="font-weight:600;font-size:14px;color:#e2e5f0;margin-bottom:4px;">${esc(b.title)}</div>
      <div style="font-size:13px;color:#8b90a8;line-height:1.5;margin-bottom:4px;">${esc(b.description)}</div>
      ${b.url ? `<div style="font-size:11px;color:#4a4f6a;font-family:monospace;">${esc(b.url)}</div>` : ''}
    </div>`).join('');

  const pagesHtml = r.pagesVisited.map((p) => `
    <div style="padding:6px 0;border-bottom:1px solid #2e3248;font-size:13px;">
      <span style="color:#8b90a8;">${p.title || 'Untitled'}</span>
      <span style="color:#4a4f6a;font-family:monospace;margin-left:8px;font-size:11px;">${p.url}</span>
    </div>`).join('');

  function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><title>BetaTesterAI Report</title>
<style>body{background:#0f1117;color:#e2e5f0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;padding:0;}
.wrap{max-width:900px;margin:0 auto;padding:40px 24px;}
h1{font-size:26px;font-weight:800;color:#fff;margin-bottom:4px;}
.meta{color:#8b90a8;font-size:13px;margin-bottom:30px;}
h2{font-size:17px;font-weight:700;color:#fff;margin:28px 0 14px;}
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:30px;}
.stat{background:#1a1d27;border:1px solid #2e3248;border-radius:10px;padding:16px 10px;text-align:center;}
.sv{font-size:24px;font-weight:800;color:#fff;}
.sl{font-size:11px;color:#8b90a8;text-transform:uppercase;margin-top:4px;}
.summary{background:#1a1d27;border:1px solid #2e3248;border-radius:10px;padding:18px 20px;font-size:13px;color:#8b90a8;line-height:1.7;white-space:pre-wrap;margin-bottom:20px;}
</style></head>
<body><div class="wrap">
<h1>BetaTesterAI Report</h1>
<div class="meta">Tested: ${esc(r.sessionId)} &nbsp;·&nbsp; ${new Date(r.startTime).toLocaleString()} &nbsp;·&nbsp; Duration: ${r.duration}</div>
<div class="stats">
  <div class="stat"><div class="sv">${r.totalBugs}</div><div class="sl">Total Bugs</div></div>
  <div class="stat" style="border-color:rgba(239,68,68,0.3)"><div class="sv" style="color:#ef4444">${r.bySeverity.critical||0}</div><div class="sl">Critical</div></div>
  <div class="stat" style="border-color:rgba(249,115,22,0.3)"><div class="sv" style="color:#f97316">${r.bySeverity.high||0}</div><div class="sl">High</div></div>
  <div class="stat" style="border-color:rgba(234,179,8,0.3)"><div class="sv" style="color:#eab308">${r.bySeverity.medium||0}</div><div class="sl">Medium</div></div>
  <div class="stat" style="border-color:rgba(34,197,94,0.3)"><div class="sv" style="color:#22c55e">${r.bySeverity.low||0}</div><div class="sl">Low</div></div>
  <div class="stat"><div class="sv">${r.pagesVisited.length}</div><div class="sl">Pages</div></div>
</div>
${r.summary ? `<h2>Summary</h2><div class="summary">${esc(r.summary)}</div>` : ''}
<h2>Bugs Found (${r.totalBugs})</h2>
${r.bugs.length ? bugsHtml : '<p style="color:#8b90a8">No bugs found.</p>'}
<h2>Pages Visited (${r.pagesVisited.length})</h2>
${pagesHtml || '<p style="color:#8b90a8">None recorded.</p>'}
<p style="margin-top:40px;color:#4a4f6a;font-size:11px;text-align:center;">Generated by BetaTesterAI</p>
</div></body></html>`;
}

function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
